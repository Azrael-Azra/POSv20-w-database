﻿namespace POS_System
{
    partial class InventoryReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgv_showData = new System.Windows.Forms.DataGridView();
            this.pnlBg = new System.Windows.Forms.Panel();
            this.btn_view2 = new System.Windows.Forms.Button();
            this.pnl_stockIN = new System.Windows.Forms.Panel();
            this.lbl_noDataFound = new System.Windows.Forms.Label();
            this.cmb_stockNumber = new System.Windows.Forms.ComboBox();
            this.lblstockNumber = new System.Windows.Forms.Label();
            this.dgv_stockOut = new System.Windows.Forms.DataGridView();
            this.cmb_reports = new System.Windows.Forms.ComboBox();
            this.lblProducts = new System.Windows.Forms.Label();
            this.pnlInformation = new System.Windows.Forms.Panel();
            this.pnl_date1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitleInfo = new System.Windows.Forms.Label();
            this.btn_filterBYdate1 = new System.Windows.Forms.Button();
            this.FromDatePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.ToDatePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.pnl_stockOut = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.pnl_date2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_filterBYdate2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.ToDatePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.FromDatePicker2 = new System.Windows.Forms.DateTimePicker();
            this.lblfrom = new System.Windows.Forms.Label();
            this.lbl_productID2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_productName2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showData)).BeginInit();
            this.pnlBg.SuspendLayout();
            this.pnl_stockIN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_stockOut)).BeginInit();
            this.pnlInformation.SuspendLayout();
            this.pnl_date1.SuspendLayout();
            this.pnl_stockOut.SuspendLayout();
            this.pnl_date2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Inter", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.lblTitle.Location = new System.Drawing.Point(37, 39);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(145, 23);
            this.lblTitle.TabIndex = 89;
            this.lblTitle.Text = "Inventory Report";
            // 
            // dgv_showData
            // 
            this.dgv_showData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_showData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_showData.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.dgv_showData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_showData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_showData.Location = new System.Drawing.Point(12, 40);
            this.dgv_showData.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_showData.Name = "dgv_showData";
            this.dgv_showData.ReadOnly = true;
            this.dgv_showData.RowHeadersWidth = 51;
            this.dgv_showData.RowTemplate.Height = 24;
            this.dgv_showData.Size = new System.Drawing.Size(723, 252);
            this.dgv_showData.TabIndex = 44;
            this.dgv_showData.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_showData_CellClick);
            // 
            // pnlBg
            // 
            this.pnlBg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBg.BackColor = System.Drawing.Color.White;
            this.pnlBg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBg.Controls.Add(this.lbl_noDataFound);
            this.pnlBg.Controls.Add(this.btn_view2);
            this.pnlBg.Controls.Add(this.pnl_stockIN);
            this.pnlBg.Controls.Add(this.dgv_stockOut);
            this.pnlBg.Controls.Add(this.cmb_reports);
            this.pnlBg.Controls.Add(this.dgv_showData);
            this.pnlBg.Controls.Add(this.lblProducts);
            this.pnlBg.Location = new System.Drawing.Point(42, 182);
            this.pnlBg.Name = "pnlBg";
            this.pnlBg.Size = new System.Drawing.Size(750, 306);
            this.pnlBg.TabIndex = 90;
            // 
            // btn_view2
            // 
            this.btn_view2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(182)))), ((int)(((byte)(102)))));
            this.btn_view2.FlatAppearance.BorderSize = 0;
            this.btn_view2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_view2.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_view2.Location = new System.Drawing.Point(220, 11);
            this.btn_view2.Name = "btn_view2";
            this.btn_view2.Size = new System.Drawing.Size(81, 24);
            this.btn_view2.TabIndex = 1;
            this.btn_view2.Text = "View History";
            this.btn_view2.UseVisualStyleBackColor = false;
            this.btn_view2.Click += new System.EventHandler(this.btn_view2_Click);
            // 
            // pnl_stockIN
            // 
            this.pnl_stockIN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_stockIN.Controls.Add(this.cmb_stockNumber);
            this.pnl_stockIN.Controls.Add(this.lblstockNumber);
            this.pnl_stockIN.Location = new System.Drawing.Point(525, 3);
            this.pnl_stockIN.Name = "pnl_stockIN";
            this.pnl_stockIN.Size = new System.Drawing.Size(210, 32);
            this.pnl_stockIN.TabIndex = 86;
            this.pnl_stockIN.Visible = false;
            // 
            // lbl_noDataFound
            // 
            this.lbl_noDataFound.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_noDataFound.AutoSize = true;
            this.lbl_noDataFound.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_noDataFound.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(69)))), ((int)(((byte)(69)))));
            this.lbl_noDataFound.Location = new System.Drawing.Point(432, 13);
            this.lbl_noDataFound.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_noDataFound.Name = "lbl_noDataFound";
            this.lbl_noDataFound.Size = new System.Drawing.Size(85, 16);
            this.lbl_noDataFound.TabIndex = 85;
            this.lbl_noDataFound.Text = "No Data Found";
            this.lbl_noDataFound.Visible = false;
            // 
            // cmb_stockNumber
            // 
            this.cmb_stockNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmb_stockNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_stockNumber.FormattingEnabled = true;
            this.cmb_stockNumber.Location = new System.Drawing.Point(89, 5);
            this.cmb_stockNumber.Name = "cmb_stockNumber";
            this.cmb_stockNumber.Size = new System.Drawing.Size(121, 21);
            this.cmb_stockNumber.TabIndex = 47;
            this.cmb_stockNumber.SelectedIndexChanged += new System.EventHandler(this.cmb_stockNumber_SelectedIndexChanged);
            // 
            // lblstockNumber
            // 
            this.lblstockNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblstockNumber.AutoSize = true;
            this.lblstockNumber.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstockNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblstockNumber.Location = new System.Drawing.Point(0, 10);
            this.lblstockNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstockNumber.Name = "lblstockNumber";
            this.lblstockNumber.Size = new System.Drawing.Size(82, 16);
            this.lblstockNumber.TabIndex = 85;
            this.lblstockNumber.Text = "Stock Number";
            // 
            // dgv_stockOut
            // 
            this.dgv_stockOut.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_stockOut.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_stockOut.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.dgv_stockOut.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_stockOut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_stockOut.Location = new System.Drawing.Point(12, 40);
            this.dgv_stockOut.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_stockOut.Name = "dgv_stockOut";
            this.dgv_stockOut.ReadOnly = true;
            this.dgv_stockOut.RowHeadersWidth = 51;
            this.dgv_stockOut.RowTemplate.Height = 24;
            this.dgv_stockOut.Size = new System.Drawing.Size(723, 252);
            this.dgv_stockOut.TabIndex = 46;
            this.dgv_stockOut.Visible = false;
            this.dgv_stockOut.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_stockOut_CellClick);
            // 
            // cmb_reports
            // 
            this.cmb_reports.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_reports.FormattingEnabled = true;
            this.cmb_reports.Items.AddRange(new object[] {
            "Delivery Report",
            "Stock-Out Report"});
            this.cmb_reports.Location = new System.Drawing.Point(85, 13);
            this.cmb_reports.Name = "cmb_reports";
            this.cmb_reports.Size = new System.Drawing.Size(121, 21);
            this.cmb_reports.TabIndex = 45;
            this.cmb_reports.SelectedIndexChanged += new System.EventHandler(this.cmb_reports_SelectedIndexChanged);
            // 
            // lblProducts
            // 
            this.lblProducts.AutoSize = true;
            this.lblProducts.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProducts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.lblProducts.Location = new System.Drawing.Point(13, 13);
            this.lblProducts.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProducts.Name = "lblProducts";
            this.lblProducts.Size = new System.Drawing.Size(64, 21);
            this.lblProducts.TabIndex = 42;
            this.lblProducts.Text = "Reports";
            // 
            // pnlInformation
            // 
            this.pnlInformation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlInformation.BackColor = System.Drawing.Color.White;
            this.pnlInformation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInformation.Controls.Add(this.pnl_date1);
            this.pnlInformation.Location = new System.Drawing.Point(41, 75);
            this.pnlInformation.Margin = new System.Windows.Forms.Padding(2);
            this.pnlInformation.Name = "pnlInformation";
            this.pnlInformation.Size = new System.Drawing.Size(749, 86);
            this.pnlInformation.TabIndex = 95;
            // 
            // pnl_date1
            // 
            this.pnl_date1.Controls.Add(this.label1);
            this.pnl_date1.Controls.Add(this.lblTitleInfo);
            this.pnl_date1.Controls.Add(this.btn_filterBYdate1);
            this.pnl_date1.Controls.Add(this.FromDatePicker1);
            this.pnl_date1.Controls.Add(this.label8);
            this.pnl_date1.Controls.Add(this.ToDatePicker1);
            this.pnl_date1.Controls.Add(this.label6);
            this.pnl_date1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_date1.Location = new System.Drawing.Point(0, 0);
            this.pnl_date1.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_date1.Name = "pnl_date1";
            this.pnl_date1.Size = new System.Drawing.Size(747, 84);
            this.pnl_date1.TabIndex = 99;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(373, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 21);
            this.label1.TabIndex = 98;
            this.label1.Text = "Actions";
            // 
            // lblTitleInfo
            // 
            this.lblTitleInfo.AutoSize = true;
            this.lblTitleInfo.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTitleInfo.Location = new System.Drawing.Point(10, 8);
            this.lblTitleInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitleInfo.Name = "lblTitleInfo";
            this.lblTitleInfo.Size = new System.Drawing.Size(114, 21);
            this.lblTitleInfo.TabIndex = 69;
            this.lblTitleInfo.Text = "Filter Inventory";
            // 
            // btn_filterBYdate1
            // 
            this.btn_filterBYdate1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.btn_filterBYdate1.FlatAppearance.BorderSize = 0;
            this.btn_filterBYdate1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_filterBYdate1.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filterBYdate1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_filterBYdate1.Location = new System.Drawing.Point(376, 34);
            this.btn_filterBYdate1.Name = "btn_filterBYdate1";
            this.btn_filterBYdate1.Size = new System.Drawing.Size(95, 40);
            this.btn_filterBYdate1.TabIndex = 90;
            this.btn_filterBYdate1.Text = "Filter by date";
            this.btn_filterBYdate1.UseVisualStyleBackColor = false;
            this.btn_filterBYdate1.Click += new System.EventHandler(this.btn_filterBYdate1_Click);
            // 
            // FromDatePicker1
            // 
            this.FromDatePicker1.Location = new System.Drawing.Point(14, 54);
            this.FromDatePicker1.Name = "FromDatePicker1";
            this.FromDatePicker1.Size = new System.Drawing.Size(168, 20);
            this.FromDatePicker1.TabIndex = 86;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.label8.Location = new System.Drawing.Point(11, 34);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 17);
            this.label8.TabIndex = 88;
            this.label8.Text = "From";
            // 
            // ToDatePicker1
            // 
            this.ToDatePicker1.Location = new System.Drawing.Point(198, 54);
            this.ToDatePicker1.Name = "ToDatePicker1";
            this.ToDatePicker1.Size = new System.Drawing.Size(168, 20);
            this.ToDatePicker1.TabIndex = 87;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.label6.Location = new System.Drawing.Point(195, 34);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 17);
            this.label6.TabIndex = 89;
            this.label6.Text = "To";
            // 
            // pnl_stockOut
            // 
            this.pnl_stockOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_stockOut.BackColor = System.Drawing.Color.White;
            this.pnl_stockOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_stockOut.Controls.Add(this.label9);
            this.pnl_stockOut.Controls.Add(this.pnl_date2);
            this.pnl_stockOut.Controls.Add(this.lbl_productID2);
            this.pnl_stockOut.Controls.Add(this.label7);
            this.pnl_stockOut.Controls.Add(this.lbl_productName2);
            this.pnl_stockOut.Controls.Add(this.label5);
            this.pnl_stockOut.Location = new System.Drawing.Point(41, 75);
            this.pnl_stockOut.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_stockOut.Name = "pnl_stockOut";
            this.pnl_stockOut.Size = new System.Drawing.Size(749, 86);
            this.pnl_stockOut.TabIndex = 96;
            this.pnl_stockOut.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label9.Location = new System.Drawing.Point(9, 10);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 21);
            this.label9.TabIndex = 91;
            this.label9.Text = "Details";
            // 
            // pnl_date2
            // 
            this.pnl_date2.Controls.Add(this.label3);
            this.pnl_date2.Controls.Add(this.btn_filterBYdate2);
            this.pnl_date2.Controls.Add(this.label2);
            this.pnl_date2.Controls.Add(this.ToDatePicker2);
            this.pnl_date2.Controls.Add(this.label4);
            this.pnl_date2.Controls.Add(this.FromDatePicker2);
            this.pnl_date2.Controls.Add(this.lblfrom);
            this.pnl_date2.Location = new System.Drawing.Point(251, 0);
            this.pnl_date2.Name = "pnl_date2";
            this.pnl_date2.Size = new System.Drawing.Size(496, 84);
            this.pnl_date2.TabIndex = 97;
            this.pnl_date2.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(13, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 21);
            this.label3.TabIndex = 91;
            this.label3.Text = "Filter";
            // 
            // btn_filterBYdate2
            // 
            this.btn_filterBYdate2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.btn_filterBYdate2.FlatAppearance.BorderSize = 0;
            this.btn_filterBYdate2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_filterBYdate2.Font = new System.Drawing.Font("Inter", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filterBYdate2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_filterBYdate2.Location = new System.Drawing.Point(378, 37);
            this.btn_filterBYdate2.Name = "btn_filterBYdate2";
            this.btn_filterBYdate2.Size = new System.Drawing.Size(99, 37);
            this.btn_filterBYdate2.TabIndex = 90;
            this.btn_filterBYdate2.Text = "Filter by date";
            this.btn_filterBYdate2.UseVisualStyleBackColor = false;
            this.btn_filterBYdate2.Click += new System.EventHandler(this.btn_filterBYdate2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Inter", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(375, 10);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 21);
            this.label2.TabIndex = 84;
            this.label2.Text = "Actions";
            // 
            // ToDatePicker2
            // 
            this.ToDatePicker2.Location = new System.Drawing.Point(200, 56);
            this.ToDatePicker2.Name = "ToDatePicker2";
            this.ToDatePicker2.Size = new System.Drawing.Size(168, 20);
            this.ToDatePicker2.TabIndex = 87;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.label4.Location = new System.Drawing.Point(197, 37);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 17);
            this.label4.TabIndex = 89;
            this.label4.Text = "To";
            // 
            // FromDatePicker2
            // 
            this.FromDatePicker2.Location = new System.Drawing.Point(15, 56);
            this.FromDatePicker2.Name = "FromDatePicker2";
            this.FromDatePicker2.Size = new System.Drawing.Size(168, 20);
            this.FromDatePicker2.TabIndex = 86;
            // 
            // lblfrom
            // 
            this.lblfrom.AutoSize = true;
            this.lblfrom.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfrom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lblfrom.Location = new System.Drawing.Point(14, 36);
            this.lblfrom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblfrom.Name = "lblfrom";
            this.lblfrom.Size = new System.Drawing.Size(38, 17);
            this.lblfrom.TabIndex = 88;
            this.lblfrom.Text = "From";
            // 
            // lbl_productID2
            // 
            this.lbl_productID2.AutoSize = true;
            this.lbl_productID2.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productID2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lbl_productID2.Location = new System.Drawing.Point(14, 55);
            this.lbl_productID2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_productID2.Name = "lbl_productID2";
            this.lbl_productID2.Size = new System.Drawing.Size(20, 17);
            this.lbl_productID2.TabIndex = 81;
            this.lbl_productID2.Text = "--";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label7.Location = new System.Drawing.Point(10, 34);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 16);
            this.label7.TabIndex = 63;
            this.label7.Text = "Product ID";
            // 
            // lbl_productName2
            // 
            this.lbl_productName2.AutoSize = true;
            this.lbl_productName2.Font = new System.Drawing.Font("Inter", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productName2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(58)))), ((int)(((byte)(65)))));
            this.lbl_productName2.Location = new System.Drawing.Point(125, 55);
            this.lbl_productName2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_productName2.Name = "lbl_productName2";
            this.lbl_productName2.Size = new System.Drawing.Size(20, 17);
            this.lbl_productName2.TabIndex = 83;
            this.lbl_productName2.Text = "--";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.label5.Location = new System.Drawing.Point(125, 34);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 16);
            this.label5.TabIndex = 65;
            this.label5.Text = "Product Name";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Location = new System.Drawing.Point(41, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 116);
            this.panel1.TabIndex = 97;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Inter", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label11.Location = new System.Drawing.Point(7, 68);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(312, 16);
            this.label11.TabIndex = 86;
            this.label11.Text = "Please choose a report category using the drop-down list!";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Inter", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.label10.Location = new System.Drawing.Point(5, 32);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(343, 28);
            this.label10.TabIndex = 87;
            this.label10.Text = "Inventory Stock-outs and Delivery";
            // 
            // InventoryReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(830, 529);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_stockOut);
            this.Controls.Add(this.pnlInformation);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.pnlBg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InventoryReport";
            this.Text = "TransactionReport";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showData)).EndInit();
            this.pnlBg.ResumeLayout(false);
            this.pnlBg.PerformLayout();
            this.pnl_stockIN.ResumeLayout(false);
            this.pnl_stockIN.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_stockOut)).EndInit();
            this.pnlInformation.ResumeLayout(false);
            this.pnl_date1.ResumeLayout(false);
            this.pnl_date1.PerformLayout();
            this.pnl_stockOut.ResumeLayout(false);
            this.pnl_stockOut.PerformLayout();
            this.pnl_date2.ResumeLayout(false);
            this.pnl_date2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgv_showData;
        private System.Windows.Forms.Panel pnlBg;
        private System.Windows.Forms.Label lblProducts;
        private System.Windows.Forms.ComboBox cmb_reports;
        private System.Windows.Forms.Panel pnlInformation;
        private System.Windows.Forms.Label lblTitleInfo;
        private System.Windows.Forms.DataGridView dgv_stockOut;
        private System.Windows.Forms.Panel pnl_stockOut;
        private System.Windows.Forms.ComboBox cmb_stockNumber;
        private System.Windows.Forms.Panel pnl_stockIN;
        private System.Windows.Forms.Label lblstockNumber;
        private System.Windows.Forms.Label lbl_noDataFound;
        private System.Windows.Forms.DateTimePicker FromDatePicker2;
        private System.Windows.Forms.Button btn_filterBYdate2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblfrom;
        private System.Windows.Forms.DateTimePicker ToDatePicker2;
        private System.Windows.Forms.Button btn_filterBYdate1;
        private System.Windows.Forms.DateTimePicker ToDatePicker1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker FromDatePicker1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnl_date2;
        private System.Windows.Forms.Button btn_view2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_productID2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_productName2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnl_date1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}