﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_System
{
    public partial class InventoryReport : Form
    {
        //add Database context and Variable declaration
        databasePOS db;
        int currentIndex;
        string stockNumber;
        public InventoryReport()
        {
            InitializeComponent();
            btn_view2.Hide();
        }
        private void showReports(string stockNumber)
        {
            //Clears data
            dgv_showData.DataSource = null;

            //Instantiate the database
            db = new databasePOS();

            //Populate datagridview
            //var filter = db.showStockNumberReport(stockNumber).ToList();
            DateTime fromDate = FromDatePicker2.Value.Date;
            DateTime toDate = ToDatePicker2.Value.Date;

            var filter = db.showDeliveryReports("Stock-In");
            
            var stock = filter.Where(u => u.StockNumber == stockNumber).ToList();
            var filteredData = stock.Where(t => t.DATE >= fromDate && t.DATE <= toDate).ToList();

            if (filteredData.Count > 0)
            {
                lbl_noDataFound.Hide();
                dgv_showData.DataSource = filteredData;


                //Change header texts
                dgv_showData.Columns[0].HeaderText = "Stock Number";
                dgv_showData.Columns[1].HeaderText = "Product ID";
                dgv_showData.Columns[2].HeaderText = "Product Name";
                dgv_showData.Columns[3].HeaderText = "Added by UserID";
                dgv_showData.Columns[4].HeaderText = "Quantity Added";
                dgv_showData.Columns[5].HeaderText = "Date Added";
                dgv_showData.Columns[6].HeaderText = "Category";

            }
            else
            {
                lbl_noDataFound.Show();
            }

            
        }

        private void cmb_reports_SelectedIndexChanged(object sender, EventArgs e)
        {
            //switches reports
            switch (cmb_reports.SelectedIndex)
            {
                //Delivery reports
                case 0:
                    //showReports();
                    pnl_stockOut.Hide();
                    pnlInformation.Show();
                    dgv_showData.Show();
                    dgv_stockOut.Hide();
                    //pnl_stockIN.Show();
                    //cmb_stockNumber.SelectedIndex = 0;
                    pnl_date1.Show();
                    btn_view2.Hide();
                    panel1.Hide();
                    break;

                //Stock-out reports
                case 1:
                    showProducts();
                    pnl_stockIN.Hide();
                    dgv_stockOut.CellClick += dgv_stockOut_CellClick;
                    btn_view2.Text = "View History";
                    btn_view2.BackColor = Color.FromArgb(1, 182, 102);
                    btn_view2.Show();
                    panel1.Hide();
                    break;
            }
        }

        private void showProducts()
        {
            pnl_stockOut.Show();
            pnlInformation.Hide();
            dgv_stockOut.Show();
            dgv_showData.Hide();
            db = new databasePOS();
            dgv_stockOut.DataSource = null;

            //Gets product list
            var productList = db.tblProducts.Select(u => new
            {
                u.Product_ID,
                u.Product_Name
            }).ToList();

            dgv_stockOut.DataSource = productList;
        }

        private void dgv_showData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_view2_Click(object sender, EventArgs e)
        {
            if (btn_view2.Text == "View History")
            {
                if (lbl_productName2.Text != "--")
                {
                    //shows product stock-out history
                    db = new databasePOS();

                    dgv_stockOut.DataSource = null;
                    var product = db.showProductStockOut(currentIndex);
                    dgv_stockOut.DataSource =  product.OrderByDescending(u => u.Transaction_ID).ToList();
                    btn_view2.Text = "Return";
                    btn_view2.BackColor = Color.FromArgb(207, 69, 69);
                    pnl_date2.Show();
                    dgv_stockOut.CellClick -= dgv_stockOut_CellClick;
                }
            }
            else
            {
                showProducts();
                dgv_stockOut.CellClick += dgv_stockOut_CellClick;
                btn_view2.Text = "View History";
                btn_view2.BackColor = Color.FromArgb(1, 182, 102);
                pnl_date2.Hide();
            }
            
            
        }

        //Gets the selected row information
        private void dgv_stockOut_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                //Gets the product ID
                currentIndex = int.Parse(dgv_stockOut.Rows[e.RowIndex].Cells[0].Value.ToString());
                var product = db.tblProducts.FirstOrDefault(u => u.Product_ID == currentIndex);

                if (product != null)
                {
                    lbl_productID2.Text = product.Product_ID.ToString();
                    lbl_productName2.Text = product.Product_Name.ToString();
                }
            }
        }

        private void cmb_stockNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            stockNumber =  cmb_stockNumber.SelectedItem.ToString();
            showReports(stockNumber);


        }

        private void btn_filterBYdate2_Click(object sender, EventArgs e)
        {
            db = new databasePOS();
            dgv_stockOut.DataSource = null;
            DateTime fromDate = FromDatePicker2.Value.Date;
            DateTime toDate = ToDatePicker2.Value.Date;

            var filter = db.showProductStockOut(currentIndex);

            var filteredData = filter
                .Where(t => t.DATE >= fromDate && t.DATE <= toDate).ToList();
            if (filteredData.Count > 0)
            {
                dgv_stockOut.DataSource = filteredData;
                lbl_noDataFound.Hide();
            }
            else
            {
                lbl_noDataFound.Show();
            }
            
        }

        private void btn_filterBYdate1_Click(object sender, EventArgs e)
        {
            db = new databasePOS();
            dgv_showData.DataSource = null;
            DateTime fromDate = FromDatePicker1.Value.Date;
            DateTime toDate = ToDatePicker1.Value.Date;

            var filter = db.showDeliveryReports("Stock-In");
            var filteredData = filter.Where(t => t.DATE >= fromDate && t.DATE <= toDate).ToList();
            var stockNumber = filteredData.Select(u => u.StockNumber).Distinct().ToList();

            if (filteredData.Count > 0)
            {
                cmb_stockNumber.Items.Clear();
                foreach (var a in stockNumber)
                {
                    cmb_stockNumber.Items.Add(a);
                }


                dgv_showData.DataSource = filteredData;
                lbl_noDataFound.Hide();

                //Change header texts
                dgv_showData.Columns[0].HeaderText = "Stock Number";
                dgv_showData.Columns[1].HeaderText = "Product ID";
                dgv_showData.Columns[2].HeaderText = "Product Name";
                dgv_showData.Columns[3].HeaderText = "Added by UserID";
                dgv_showData.Columns[4].HeaderText = "Quantity Added";
                dgv_showData.Columns[5].HeaderText = "Date Added";
                dgv_showData.Columns[6].HeaderText = "Category";

                pnl_stockIN.Show();
            }
            else
            {
                pnl_stockIN.Hide();
                lbl_noDataFound.Show();
            }





        }
    }
}
